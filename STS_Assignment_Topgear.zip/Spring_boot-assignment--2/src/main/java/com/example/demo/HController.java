package com.example.demo;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class HController {
	
	
	
	@RequestMapping("/bankName")
	public ModelAndView bankName() {
		
	    ModelAndView modelAndView = new ModelAndView();
	    modelAndView.setViewName("bankName.jsp");
	    return modelAndView;
	}
	
	@RequestMapping("/bankService")
	public ModelAndView bankAddress() {
		
	    ModelAndView modelAndView = new ModelAndView();
	    modelAndView.setViewName("bankService.jsp");
	    return modelAndView;
	}
	
	
	
	

}
