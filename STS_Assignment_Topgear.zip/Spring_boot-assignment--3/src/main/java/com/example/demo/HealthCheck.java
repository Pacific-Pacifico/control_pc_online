package com.example.demo;

import java.net.URL;

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
@Service
@Component
public interface HealthCheck extends HealthIndicator{
	public Health health(String url);

}
