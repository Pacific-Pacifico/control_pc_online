package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class HomeController {
	@Autowired
	EmployeeRepository repo;
	
	@GetMapping("/")
	public ModelAndView home()
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("index.jsp");
		return mv;
	}
	
	@GetMapping("/getEmployees")
	public ModelAndView getEmployees()
	{
		System.out.println("coming...........");
		ModelAndView mv=new ModelAndView();
		mv.addObject("result", repo.findAll());
		mv.setViewName("result.jsp");
		return mv;
	}
	
	@GetMapping(path="/getEmployeeById")
	public ModelAndView getEmployeeById(@RequestParam int id)
	{
		
		ModelAndView mv=new ModelAndView();
		mv.addObject("result", repo.getOne(id));
		mv.setViewName("result.jsp");
		return mv;
	}
	
	@PostMapping(path="/addEmployee")
	public ModelAndView addEmployee(@ModelAttribute Employee e)
	{
		
		repo.save(e);
		ModelAndView mv=new ModelAndView();
		mv.addObject("result","Data Saved Successfully");
		mv.setViewName("result.jsp");
		return mv;
	}
	

}
