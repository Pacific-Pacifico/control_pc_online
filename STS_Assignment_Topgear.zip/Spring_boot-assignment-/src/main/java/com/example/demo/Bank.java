package com.example.demo;

import org.springframework.stereotype.Service;

@Service
public class Bank {
	
	public Bank() {}
	
	private String bankName;
	private String bankAddress;
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBankAddress() {
		return bankAddress;
	}
	public void setBankAddress(String bankAddress) {
		this.bankAddress = bankAddress;
	}
	@Override
	public String toString() {
		return "Bank [bankName=" + bankName + ", bankAddress=" + bankAddress + "]";
	}
	public Bank(String bankName, String bankAddress) {
		super();
		this.bankName = bankName;
		this.bankAddress = bankAddress;
	}
	
	
	

}
