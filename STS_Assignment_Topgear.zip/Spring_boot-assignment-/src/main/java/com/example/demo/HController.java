package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class HController {
	@Autowired
	Bank b;
	
	@RequestMapping("/bankName")
	public String bankName()
	{
		b= new Bank("SBI", "Neeladri");
		
		return b.getBankName();
	}
	
	@RequestMapping("/bankAddress")
	public String bankAddress()
	{
		b= new Bank("SBI", "Neeladri");
		
		return b.getBankAddress();
	}
	
	@RequestMapping("/")
	public ModelAndView index () {
	    ModelAndView modelAndView = new ModelAndView();
	    modelAndView.setViewName("home.jsp");
	    return modelAndView;
	}
	
	
	
	

}
