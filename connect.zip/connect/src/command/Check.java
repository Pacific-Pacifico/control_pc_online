package command;
import java.sql.Connection;
import java.sql.ResultSet;

public class Check
{
	int off_value=0;
	ResultSet rs;
	
	int getOff_value() {
		try {
			rs=new db.DbCommand().executeQueryCommand("3F2H7XnPSk", "select * from my_comp");
			while (rs.next()) 
			{
				off_value=rs.getInt("shutdown");
			}
			System.out.println("Connection Successful");
			System.out.println("off_value="+off_value);
		} catch (Exception e) {
			System.out.println(e);
		}
		return off_value;
	}
	
	void setOn_value()
	{
		int count;
		count=new db.DbCommand().executeDmlCommand("3F2H7XnPSk", "update my_comp set shutdown=0");
		if(count==1)
		{
			System.out.println("off_value set to 0");
		}
		else
		{
			System.out.println("error in setting off_value to 0");
		}
	}
	
	public static void main(String args[])
	{
		Check c=new Check();
		c.getOff_value();
	}
}