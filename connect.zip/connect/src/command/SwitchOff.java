package command;

import java.io.*;

public class SwitchOff {
	private String command;
	Process p;
	int off_value;

	public void execute() {
		// Get OS name
		String OS = System.getProperty("os.name").toLowerCase();
		off_value=new Check().getOff_value();
		if(off_value==1)
		{	
			if ((OS.indexOf("win") >= 0)) {
				System.out.println("Switching off in 30 seconds!");
							command = "shutdown /s /t 30";
				
			} else if ((OS.indexOf("mac") >= 0)) {

			} else if ((OS.indexOf("nux") >= 0)) {
			} else {
				// Handle error when platform is not Windows, Mac, or Linux
				System.err.println("Sorry, but your OS doesn't support blocking.");
				System.exit(0);
			}
			try {
				p = Runtime.getRuntime().exec(command);
			} catch (Exception e) {
				System.out.println("no command");
			}
			new Check().setOn_value();
		}
		else if(off_value==2)
		{	
			if ((OS.indexOf("win") >= 0)) {
				System.out.println("Restarting  in 30 seconds!");
							command = "shutdown /r /t 30";
				
			} else if ((OS.indexOf("mac") >= 0)) {

			} else if ((OS.indexOf("nux") >= 0)) {
			} else {
				// Handle error when platform is not Windows, Mac, or Linux
				System.err.println("Sorry, but your OS doesn't support blocking.");
				System.exit(0);
			}
			try {
				p = Runtime.getRuntime().exec(command);
			} catch (Exception e) {
				System.out.println("no command");
			}
			new Check().setOn_value();
		}
		else if(off_value==3)
		{	
			if ((OS.indexOf("win") >= 0)) {
				System.out.println("Hibernating!!");
							command = "shutdown /h";
				
			} else if ((OS.indexOf("mac") >= 0)) {

			} else if ((OS.indexOf("nux") >= 0)) {
			} else {
				// Handle error when platform is not Windows, Mac, or Linux
				System.err.println("Sorry, but your OS doesn't support blocking.");
				System.exit(0);
			}
			try {
				p = Runtime.getRuntime().exec(command);
			} catch (Exception e) {
				System.out.println("no command");
			}
			new Check().setOn_value();
			operate();
		}
		else if(off_value==4)
		{	
			if ((OS.indexOf("win") >= 0)) {
				System.out.println("signing out!!");
							command = "shutdown /l";
				
			} else if ((OS.indexOf("mac") >= 0)) {

			} else if ((OS.indexOf("nux") >= 0)) {
			} else {
				// Handle error when platform is not Windows, Mac, or Linux
				System.err.println("Sorry, but your OS doesn't support blocking.");
				System.exit(0);
			}
			try {
				p = Runtime.getRuntime().exec(command);
			} catch (Exception e) {
				System.out.println("no command");
			}
			new Check().setOn_value();
		}
		else if(off_value==5)
		{	
			if ((OS.indexOf("win") >= 0)) {
				System.out.println("Sleep 30 seconds!");
//							command = "RUNDLL32.EXE powrprof.dll,SetSuspendState 0,1,0";
				
			} else if ((OS.indexOf("mac") >= 0)) {

			} else if ((OS.indexOf("nux") >= 0)) {
			} else {
				// Handle error when platform is not Windows, Mac, or Linux
				System.err.println("Sorry, but your OS doesn't support blocking.");
				System.exit(0);
			}
			try {
				p = Runtime.getRuntime().exec(command);
			} catch (Exception e) {
				System.out.println("no command");
			}
			new Check().setOn_value();
		}
		else
		{
			System.out.println("continue!");
		}
	}
	
	public static void operate()
	{
		SwitchOff r = new SwitchOff();
		// connection checking continuously

		while (r.off_value==0) {
			try {
				r.execute();
//				Thread.sleep(60000); // 1 minute(s) wait
				Thread.sleep(10000); // 10 second(s) wait
			} catch (InterruptedException e) {
				System.out.println("error c3:" + e);
				e.printStackTrace();
			}
		}
	}

	public static void main(String args[]) {
		
//		System.out.println("erdftghjjjjjjjjjjjjjj");
		operate();
	}
}
