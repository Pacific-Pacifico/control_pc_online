package db;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbConnect {
	Connection con = null;
	String user, pass, url,db_name;

	public DbConnect()
	{
		user = "3F2H7XnPSk";
		pass = "cihWwAabPv";
	}
	public Connection getDbConnection(String db_name) {
		try {
			url = "jdbc:mysql://remotemysql.com:3306/" + db_name;
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url, user, pass);
			System.out.println(con);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}
		return con;
	}
}